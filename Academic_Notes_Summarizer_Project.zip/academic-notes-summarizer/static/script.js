const $ = (id) => document.getElementById(id);
let lastResult = null;
let lastPlainText = "";

function showAlert(message, type = "danger") {
  const box = $("alertBox");
  box.className = `alert alert-${type}`;
  box.textContent = message;
  box.classList.remove("d-none");
  box.scrollIntoView({behavior:"smooth", block:"center"});
}
function hideAlert() { $("alertBox").classList.add("d-none"); }
function setLoading(loading) {
  $("generateBtn").disabled = loading;
  $("buttonText").textContent = loading ? "Generating..." : "Generate Summary";
  $("spinner").classList.toggle("d-none", !loading);
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function listCard(title, items, wide=false) {
  const content = Array.isArray(items) && items.length
    ? `<ul>${items.map(item=>`<li>${escapeHtml(item)}</li>`).join("")}</ul>`
    : `<p>Not available in the provided material.</p>`;
  return `<article class="result-card ${wide?"wide":""}"><h3><span class="card-dot"></span>${title}</h3>${content}</article>`;
}
function renderResults(data) {
  const questions = data.exam_questions || {};
  const definitions = Array.isArray(data.definitions) && data.definitions.length
    ? data.definitions.map(d=>`<div class="definition"><strong>${escapeHtml(d.term)}</strong><p>${escapeHtml(d.definition)}</p></div>`).join("")
    : "<p>Not available in the provided material.</p>";
  const questionHtml = [
    ["Short-answer questions", questions.short_answer],
    ["Conceptual questions", questions.conceptual],
    ["Long-answer questions", questions.long_answer]
  ].map(([title,items])=>`<div class="question-group"><h4>${title}</h4>${Array.isArray(items)&&items.length?`<ol>${items.map(q=>`<li>${escapeHtml(q)}</li>`).join("")}</ol>`:"<p>Not available in the provided material.</p>"}</div>`).join("");
  $("resultCards").innerHTML =
    `<article class="result-card wide"><h3><span class="card-dot"></span>Main Summary</h3><p>${escapeHtml(data.main_summary)}</p></article>`+
    listCard("Key Concepts",data.key_concepts)+
    `<article class="result-card"><h3><span class="card-dot"></span>Important Definitions</h3>${definitions}</article>`+
    listCard("Important Points",data.important_points)+
    `<article class="result-card wide"><h3><span class="card-dot"></span>Exam Preparation Questions</h3>${questionHtml}</article>`+
    listCard("Quick Revision Notes",data.quick_revision_notes)+
    listCard("Key Takeaways",data.key_takeaways);
  lastResult = data;
  lastPlainText = toPlainText(data);
  $("results").classList.remove("d-none");
  $("results").scrollIntoView({behavior:"smooth",block:"start"});
}
function toPlainText(d) {
  const lines = ["ACADEMIC NOTES SUMMARIZER","", "MAIN SUMMARY", d.main_summary || "",
    "", "KEY CONCEPTS", ...(d.key_concepts||[]).map(x=>"• "+x),
    "", "IMPORTANT DEFINITIONS", ...(d.definitions||[]).map(x=>`${x.term}: ${x.definition}`),
    "", "IMPORTANT POINTS", ...(d.important_points||[]).map(x=>"• "+x),
    "", "EXAM PREPARATION QUESTIONS"];
  const q=d.exam_questions||{};
  for (const [label,key] of [["Short-answer","short_answer"],["Conceptual","conceptual"],["Long-answer","long_answer"]]) {
    lines.push("",label,...(q[key]||[]).map((x,i)=>`${i+1}. ${x}`));
  }
  lines.push("", "QUICK REVISION NOTES", ...(d.quick_revision_notes||[]).map(x=>"• "+x),
    "", "KEY TAKEAWAYS", ...(d.key_takeaways||[]).map(x=>"• "+x));
  return lines.join("\n");
}
async function generate() {
  hideAlert();
  const notes = $("notes").value.trim();
  const file = $("pdf").files[0];
  if (!notes && !file) { showAlert("Please paste your notes or choose a PDF first."); return; }
  const form = new FormData();
  form.append("notes",notes);
  if(file) form.append("pdf",file);
  form.append("style",$("style").value);
  form.append("language",$("language").value);
  setLoading(true);
  try {
    const response = await fetch("/api/summarize",{method:"POST",body:form});
    const payload = await response.json();
    if(!response.ok) throw new Error(payload.error || "The request could not be completed.");
    renderResults(payload.result);
    showAlert("Your study material is ready.", "success");
  } catch(error) {
    showAlert(error.message || "A network error occurred. Please try again.");
  } finally { setLoading(false); }
}
$("pdf").addEventListener("change",()=>{
  const file=$("pdf").files[0];
  if(file && (file.type!=="application/pdf" && !file.name.toLowerCase().endsWith(".pdf"))) {
    $("pdf").value=""; showAlert("Please choose a PDF file."); return;
  }
  if(file && file.size>12*1024*1024) {
    $("pdf").value=""; showAlert("The PDF is larger than 12 MB."); return;
  }
  $("fileName").textContent=file?file.name:"No file selected";
  $("removeFile").classList.toggle("d-none",!file);
});
$("removeFile").addEventListener("click",()=>{$("pdf").value="";$("fileName").textContent="No file selected";$("removeFile").classList.add("d-none");});
$("generateBtn").addEventListener("click",generate);
$("againBtn").addEventListener("click",generate);
$("copyBtn").addEventListener("click",async()=>{
  if(!lastPlainText)return;
  try { await navigator.clipboard.writeText(lastPlainText); showAlert("Study material copied to clipboard.","success"); }
  catch { showAlert("Copy was blocked by the browser. You can use Download Summary instead.","warning"); }
});
$("downloadBtn").addEventListener("click",()=>{
  if(!lastPlainText)return;
  const blob=new Blob([lastPlainText],{type:"text/plain;charset=utf-8"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");
  a.href=url;a.download="academic-study-notes.txt";a.click();URL.revokeObjectURL(url);
});
$("clearBtn").addEventListener("click",()=>{
  $("notes").value="";$("pdf").value="";$("fileName").textContent="No file selected";
  $("removeFile").classList.add("d-none");$("results").classList.add("d-none");
  $("resultCards").innerHTML="";lastResult=null;lastPlainText="";hideAlert();
  window.scrollTo({top:0,behavior:"smooth"});
});
