# AI-Powered Academic Notes Summarizer

A local Flask web application that turns pasted academic notes or text-based PDF documents into structured study material using the Groq API. It generates a main summary, key concepts, definitions, important points, exam questions, quick revision notes, and key takeaways.

## Features

- Paste lecture notes or upload a PDF (or use both).
- Short, detailed, and exam-preparation styles.
- English and Urdu output options.
- AI-generated study sections grounded in the supplied material.
- Copy results or download them as a `.txt` file.
- Responsive interface, loading state, and clear error messages.
- API key stays on the server in `.env`; it is never sent to browser JavaScript.
- No database. Uploaded PDFs are processed in memory and are not saved.

## Technology

- Python and Flask
- Groq Python SDK
- PyMuPDF for PDF text extraction
- python-dotenv for environment variables
- HTML, CSS, JavaScript, Bootstrap 5

## Folder structure

```text
academic-notes-summarizer/
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── script.js
└── uploads/
    └── .gitkeep
```

## Requirements

- Windows 10/11 (commands below use PowerShell)
- Python 3.10 or newer
- Internet connection for Groq API requests
- A Groq API key

## Setup on Windows PowerShell

1. Extract the ZIP file.
2. Open the extracted `academic-notes-summarizer` folder.
3. Click the folder address bar, type `powershell`, and press Enter. PowerShell will open in that folder.
4. Create a virtual environment:

```powershell
py -m venv venv
```

5. Activate it:

```powershell
venv\\Scripts\\activate
```

If PowerShell blocks activation, run this once in the current PowerShell window, then activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
venv\\Scripts\\activate
```

6. Install dependencies:

```powershell
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

## Configure your Groq API key

1. Get an API key from the Groq Console: https://console.groq.com/keys
2. In the project folder, make a copy of `.env.example` and name the copy `.env`.
   - In File Explorer, copy `.env.example`, paste it in the same folder, and rename the copy to `.env`.
   - Make sure Windows has not named it `.env.txt`. In File Explorer, enable **View → Show → File name extensions** to check.
3. Open `.env` in Notepad.
4. Replace `your_groq_api_key_here` with your own key:

```env
GROQ_API_KEY=your_real_key_here
GROQ_MODEL=llama-3.3-70b-versatile
```

Keep `.env private. Do not upload it to GitHub or share it. The `.env.example` file is safe to share because it contains only a placeholder.

You can change `GROQ_MODEL` to another model currently available to your Groq account.

## Run the application

In PowerShell, from the project folder:

```powershell
py app.py
```

Open this address in Chrome or another browser:

http://127.0.0.1:5000

Keep the PowerShell window open while using the app. To stop the server, press `Ctrl + C`.

## How to use

1. Paste academic notes, select a PDF, or provide both.
2. Choose a summary style and output language.
3. Select **Generate Summary**.
4. Review each generated section.
5. Copy the material or download the `.txt` file.
6. Use **Generate Again** to rerun the current input, or **Clear All** to reset.

## Limits and accuracy

- Maximum PDF upload size: 12 MB.
- Maximum extracted/pasted text: 100,000 characters.
- PDF extraction reads selectable text. Scanned/image-only PDFs need OCR, which is not included.
- The application instructs the model to use only the supplied source and to flag missing information. AI output can still contain mistakes; compare important study material with the original notes.
- Groq model names and API availability can change. If the configured model is unavailable, set `GROQ_MODEL` to a currently supported model in `.env`.

## Common errors

**`GROQ_API_KEY is missing`**
- Confirm `.env` is in the same folder as `app.py`.
- Confirm the file is named `.env`, not `.env.txt`.
- Check that `GROQ_API_KEY=` has your key after the equals sign.
- Restart `py app.py` after editing `.env`.

**Groq rejected the API key (401/403)**
- Check the key in the Groq Console and replace it if needed.
- Remove accidental spaces or quotation marks around the key.

**Model not found / model unavailable**
- Update `GROQ_MODEL` in `.env` to a model currently available to your Groq account.

**Could not connect to Groq**
- Check your internet connection, firewall, or VPN settings, then try again.

**Rate limit reached**
- Wait a short time and retry. Your Groq account may have request or token limits.

**No readable text was found in the PDF**
- The PDF may be scanned pages or images. Use a PDF with selectable text; OCR is not included in this version.

**`py` is not recognized**
- Install Python from https://www.python.org/downloads/ and select the option to add Python to PATH. Reopen PowerShell.

**`pip install` fails**
- Confirm the virtual environment is active. The terminal prompt should begin with `(venv)`.
- Run `py -m pip install --upgrade pip`, then retry the requirements installation.

**Port 5000 is already in use**
- Close the other app using port 5000, then run this app again.

## Security notes

- The Groq API key is read only by the Python backend.
- Do not commit `.env` or your `venv` folder to a public repository.
- This starter project does not include user accounts, persistent storage, or OCR.
