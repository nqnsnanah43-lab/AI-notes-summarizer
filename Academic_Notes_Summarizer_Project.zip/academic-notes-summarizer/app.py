import os
import re
import logging
from pathlib import Path

import fitz
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from groq import Groq
from groq import APIConnectionError, APIStatusError, RateLimitError

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent
MAX_CONTENT_LENGTH = 12 * 1024 * 1024  # 12 MB request limit
MAX_TEXT_CHARS = 100_000
ALLOWED_STYLES = {"short", "detailed", "exam"}
ALLOWED_LANGUAGES = {"English", "Urdu"}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH


def extract_pdf_text(file_storage):
    """Extract selectable text from an uploaded PDF without saving it."""
    try:
        data = file_storage.read()
        if not data:
            raise ValueError("The uploaded PDF is empty.")
        if not data.startswith(b"%PDF"):
            raise ValueError("The uploaded file is not a valid PDF.")
        with fitz.open(stream=data, filetype="pdf") as document:
            if document.is_encrypted:
                raise ValueError("This PDF is password-protected. Please upload an unlocked PDF.")
            pages = [page.get_text("text") for page in document]
        text = "\n".join(pages).strip()
        if not text:
            raise ValueError("No readable text was found. This may be a scanned PDF; OCR is not included.")
        return text
    except fitz.FileDataError as exc:
        raise ValueError("The PDF could not be read. Please check that it is not damaged.") from exc


def build_prompt(material, style, language):
    style_instructions = {
        "short": "Keep the main summary concise. Keep all other sections focused and useful.",
        "detailed": "Give a thorough explanation and include helpful detail from the source, without adding outside facts.",
        "exam": "Prioritize exam-focused explanations, likely examinable concepts, clear definitions, and quick revision points."
    }
    return f"""
You are an academic learning assistant. Transform only the user's supplied academic material into accurate, organized, student-friendly study notes.

STRICT RULES:
- Use only information in the source material. Do not invent facts, definitions, examples, references, or explanations.
- Explain difficult concepts in simple language without changing their meaning.
- Preserve important technical terminology.
- If the source does not provide enough information, write: "Not available in the provided material."
- Do not claim a question or fact is important beyond what the source supports.
- Write the entire response in {language}. Keep technical terms in their original form when useful.
- Follow this style: {style_instructions[style]}
- Return valid JSON only. Do not use Markdown fences or text before/after the JSON.

Return exactly this JSON structure:
{{
  "main_summary": "A clear summary as text, using paragraphs where useful.",
  "key_concepts": ["Concept — explanation based on source"],
  "definitions": [{{"term": "Term", "definition": "Definition based on source"}}],
  "important_points": ["Concise point"],
  "exam_questions": {{
    "short_answer": ["5 questions"],
    "conceptual": ["5 questions"],
    "long_answer": ["5 questions"]
  }},
  "quick_revision_notes": ["Short revision note"],
  "key_takeaways": ["Main lesson"]
}}

For exam_questions, provide exactly 5 questions in each of the three lists. Questions must be answerable from the supplied material. If the material is too limited, state that in the question list rather than inventing questions.

SOURCE MATERIAL:
<source>
{material}
</source>
""".strip()


def call_groq(material, style, language):
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("GROQ_API_KEY is missing. Add your key to the .env file and restart the app.")

    client = Groq(api_key=api_key)
    model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You produce faithful academic study material and valid JSON only."},
            {"role": "user", "content": build_prompt(material, style, language)}
        ],
        temperature=0.2,
        max_tokens=6000,
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("The AI returned an empty response. Please try again.")
    import json
    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        logger.exception("Groq returned invalid JSON")
        raise RuntimeError("The AI response could not be read. Please click Generate Again.") from exc

    required = ["main_summary", "key_concepts", "definitions", "important_points",
                "exam_questions", "quick_revision_notes", "key_takeaways"]
    if not isinstance(result, dict) or any(key not in result for key in required):
        raise RuntimeError("The AI response was incomplete. Please try again.")
    return result


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/summarize")
def summarize():
    pasted_text = (request.form.get("notes") or "").strip()
    uploaded_file = request.files.get("pdf")
    if not pasted_text and (not uploaded_file or not uploaded_file.filename):
        return jsonify(error="Please paste your notes or upload a PDF."), 400

    material_parts = []
    if pasted_text:
        material_parts.append(pasted_text)
    if uploaded_file and uploaded_file.filename:
        if not uploaded_file.filename.lower().endswith(".pdf"):
            return jsonify(error="Unsupported file type. Please upload a PDF file."), 400
        try:
            material_parts.append(extract_pdf_text(uploaded_file))
        except ValueError as exc:
            return jsonify(error=str(exc)), 400

    material = "\n\n".join(material_parts).strip()
    if not material:
        return jsonify(error="No readable academic material was provided."), 400
    if len(material) > MAX_TEXT_CHARS:
        return jsonify(error=f"The material is too long. Please keep it under {MAX_TEXT_CHARS:,} characters."), 413

    style = request.form.get("style", "detailed")
    language = request.form.get("language", "English")
    if style not in ALLOWED_STYLES:
        return jsonify(error="Please choose a valid summary style."), 400
    if language not in ALLOWED_LANGUAGES:
        return jsonify(error="Please choose English or Urdu."), 400

    try:
        result = call_groq(material, style, language)
        return jsonify(result=result)
    except RateLimitError:
        return jsonify(error="The Groq rate limit was reached. Please wait a moment and try again."), 429
    except APIConnectionError:
        return jsonify(error="Could not connect to Groq. Check your internet connection and try again."), 502
    except APIStatusError as exc:
        logger.warning("Groq API status error: %s", exc)
        if exc.status_code in (401, 403):
            message = "Groq rejected the API key. Check that GROQ_API_KEY in .env is correct."
        else:
            message = f"Groq API error ({exc.status_code}). Please try again later."
        return jsonify(error=message), 502
    except RuntimeError as exc:
        return jsonify(error=str(exc)), 503
    except Exception:
        logger.exception("Unexpected summarization error")
        return jsonify(error="Something went wrong while generating the study notes. Please try again."), 500


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify(error="The upload is too large. The maximum request size is 12 MB."), 413


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
